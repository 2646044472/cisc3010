"""Controlled arrival-order diagnostic after the large random-mix suite.

The diagnostic gateway changes only workload construction. Request routing,
admission, model execution, warmup and checking use the normal project code.
Alternating long/short requests deliberately probe round-robin order aliasing.
Both phases are measured; this is a diagnostic workload, not production traffic.
"""
from __future__ import annotations
import argparse,datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from llm_lab.common import json_http,write_json
from llm_lab.experiment import run_remote,workload as random_workload

URL='http://127.0.0.1:8800'
PPT=Path('C:/Users/bankey/Documents/Codex/2026-10-23/ppt')

def diagnostic_workload(count,rate,seed,run_id):
    if seed not in (3010,3011):raise ValueError('Diagnostic seed selects the explicit starting phase, not a seed search')
    items=random_workload(count,rate,3010,run_id)
    proto={c:dict(next(x for x in items if x['class']==c)) for c in ['short','long']}
    phase=0 if seed==3010 else 1
    for i,x in enumerate(items):
        cls='long' if i%2==phase else 'short'
        x.update({k:proto[cls][k] for k in ['prompt','max_tokens','class']})
        x['diagnostic_pattern']='long_first' if phase==0 else 'short_first'
    assert sum(x['class']=='long' for x in items)==count//2
    return items

def serve():
    import llm_lab.experiment as experiment_module
    from llm_lab.gateway import serve_gateway
    experiment_module.workload=diagnostic_workload
    write_json(ROOT/'runs/service/routing-diagnostic-owner.json',{'gateway_pid':os.getpid(),'source':str(Path(__file__).resolve())})
    serve_gateway(8800,'cpu-model',str(ROOT/'.runtime/qwen25-05b'),2,2)

def state():
    try:return json_http(URL+'/api/state',timeout=3)
    except Exception:return None

def idle(s):
    return s and s['backend']=='cpu-model' and len(s['workers'])==2 and not(s.get('run') and s['run']['status']=='running') and all(w.get('healthy') and not w.get('active') and not w.get('queued') and not w.get('outstanding') for w in s['workers'])

def wait_ready(timeout=180):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        s=state()
        if idle(s):return s
        time.sleep(1)
    raise RuntimeError('Two idle real-model workers were not ready')

def stop_owned(expected_pid):
    s=state()
    if not idle(s) or s['gateway_pid']!=expected_pid:raise RuntimeError('Refusing to stop a busy or unowned deployment')
    json_http(URL+'/api/shutdown',{})
    end=time.monotonic()+40
    while time.monotonic()<end:
        open_ports=False
        for port in (8800,8801,8802):
            import socket
            with socket.socket() as connection:
                connection.settimeout(.2)
                if connection.connect_ex(('127.0.0.1',port))==0:open_ports=True
        if not open_ports:return
        time.sleep(.5)
    raise RuntimeError('Old deployment did not fully release its ports')

def spawn(args,log):
    stream=log.open('w',encoding='utf-8')
    env=os.environ.copy();env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    proc=subprocess.Popen([sys.executable,'-u',*args],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,
                          env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    return proc,stream

def await_baseline(log):
    last_count=-1
    while True:
        lines=log.read_text(encoding='utf-8-sig').splitlines() if log.exists() else []
        runs=[]
        for line in lines:
            try:
                value=json.loads(line)
                if 'run_id' in value:runs.append(value)
            except (ValueError,TypeError):pass
        if len(runs)!=last_count:
            print('Waiting for random-mix suite:',len(runs),'/24 trials',flush=True);last_count=len(runs)
        for line in reversed(lines):
            candidate=Path(line.strip())
            if line.strip() and candidate.is_absolute() and (candidate/'results.json').is_file():
                rows=json.loads((candidate/'results.json').read_text(encoding='utf-8'))
                if len(rows)!=24 or any(not r['check']['passed'] or r['successes']!=120 for r in rows):raise RuntimeError('Baseline suite was not complete and valid')
                return candidate
        if any('Traceback' in line for line in lines):raise RuntimeError('Baseline suite failed; diagnostic will not conceal or replace it')
        time.sleep(15)

def main(log):
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')
    folder=ROOT/'runs/llm'/('routing-order-diagnostic-'+stamp)
    folder.mkdir(parents=True)
    protocol={'family':'arrival-order diagnostic','count_per_trial':64,'rate':3,'repeats_per_phase_per_policy':4,
              'phases':['long_first','short_first'],'policies':['round_robin','least_outstanding'],
              'total_requests':1024,'long_fraction':.5,'purpose':'Explicit stress case: order aliasing of round robin, with phase reversal.',
              'interpretation':'Report separately from random-mix results. Do not infer representative production gains.',
              'same_model_execution':True,'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'status':'waiting_for_baseline','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    write_json(folder/'protocol.json',protocol)
    print('DIAGNOSTIC_FOLDER',folder,flush=True)
    baseline=await_baseline(log)
    initial=wait_ready()
    owner=json.loads((PPT/'.demo-runtime/owned-service.json').read_text(encoding='utf-8-sig'))
    if initial['gateway_pid']!=owner['pid']:raise RuntimeError('Original gateway ownership does not match the presentation launcher')
    stop_owned(initial['gateway_pid'])
    diagnostic=None;diagnostic_pid=None;stream=None;results=[]
    try:
        diagnostic,stream=spawn([str(Path(__file__).resolve()),'--serve'],folder/'service.log')
        ready=wait_ready()
        identity=json.loads((ROOT/'runs/service/routing-diagnostic-owner.json').read_text(encoding='utf-8'))
        if identity['gateway_pid']!=ready['gateway_pid']:raise RuntimeError('Diagnostic gateway ownership mismatch')
        diagnostic_pid=ready['gateway_pid']
        protocol.update(status='running',baseline_suite=str(baseline));write_json(folder/'protocol.json',protocol)
        for seed,phase in [(3010,'long_first'),(3011,'short_first')]:
            for repeat in range(1,5):
                policies=['round_robin','least_outstanding']
                if repeat%2==0:policies.reverse()
                for policy in policies:
                    r=run_remote(URL,{'count':64,'rate':3,'seed':seed,'scenario':'routing','routing':policy,
                                      'scheduling':'continuous','execution':'selective','slots':4,'kv_budget':4096,
                                      'chunked_prefill':True,'prefill_chunk':128})
                    if not r['check']['passed'] or not r['check']['all_completed']:raise RuntimeError('Diagnostic failed correctness: '+r['run_id'])
                    r.update(repeat=repeat,workload_pattern=phase,experiment_family='order_diagnostic')
                    results.append(r);write_json(folder/'results.json',results)
                    print(json.dumps({k:r[k] for k in ['run_id','workload_pattern','repeat','routing','requests_s','ttft_p95_ms','latency_p95_ms']}),flush=True)
        protocol['status']='complete';write_json(folder/'protocol.json',protocol)
        print('DIAGNOSTIC_COMPLETE',folder,flush=True)
    except Exception as error:
        protocol.update(status='failed',error=str(error));write_json(folder/'protocol.json',protocol);raise
    finally:
        s=state()
        if diagnostic and idle(s) and s['gateway_pid']==diagnostic_pid:
            stop_owned(diagnostic_pid);diagnostic.wait(timeout=10)
        if stream:stream.close()
        if state() is None:
            restored,restored_stream=spawn(['-m','llm_lab','serve','--port','8800','--backend','cpu-model','--workers','2','--threads','2'],folder/'restored-service.log')
            ready=wait_ready()
            write_json(PPT/'.demo-runtime/owned-service.json',{'pid':ready['gateway_pid'],'project':str(ROOT),'url':URL,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()})
            write_json(folder/'restored-state.json',{'gateway_pid':ready['gateway_pid'],'worker_pids':[w['pid'] for w in ready['workers']],'healthy':True})
            restored_stream.close();print('STANDARD_DEMO_RESTORED',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--serve',action='store_true');parser.add_argument('--after-log',type=Path)
    args=parser.parse_args()
    if args.serve:serve()
    elif args.after_log:main(args.after_log)
    else:parser.error('--after-log is required')
