"""Validate and summarize the complete expanded routing experiment, never selected best runs."""
from __future__ import annotations
import argparse,collections,csv,datetime,hashlib,html,importlib.util,json,math,statistics,subprocess,sys,time,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from llm_lab.check import check_run
from llm_lab.common import read_worker_events
from llm_lab.experiment import percentile
PPT=Path('C:/Users/bankey/Documents/Codex/2026-10-23/ppt')
OUT=PPT/'Expanded_Routing_Results'
LOG=ROOT/'runs/llm/routing-expanded-20261024-170420'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
POLICIES=['round_robin','least_outstanding']
METRICS=['requests_s','ttft_p95_ms','latency_p95_ms','queue_p95_ms','inter_token_p95_ms','inter_token_p99_ms']
CLASS_METRICS=[f'{kind}_{metric}' for kind in ('short','long') for metric in ('queue_p95_ms','ttft_p95_ms','latency_p95_ms')]
LABELS={'requests_s':'Successful requests / second','ttft_p95_ms':'P95 time to first token (s)',
        'latency_p95_ms':'P95 completion latency (s)','queue_p95_ms':'P95 worker queue time (s)',
        'inter_token_p95_ms':'P95 token gap (ms)','inter_token_p99_ms':'P99 token gap (ms)'}

def locate():
    lines=(LOG/'progress.log').read_text(encoding='utf-8-sig').splitlines()
    baseline=next((Path(x.strip()) for x in reversed(lines) if Path(x.strip()).is_absolute() and (Path(x.strip())/'results.json').is_file()),None)
    folders=sorted(ROOT.glob('runs/llm/routing-order-diagnostic-*'),key=lambda p:p.stat().st_mtime,reverse=True)
    diag=next((p for p in folders if (p/'protocol.json').is_file() and read(p/'protocol.json')['status']!='aborted_before_measurement'),None)
    return baseline,diag

def wait_for_completion():
    previous=None
    while True:
        try:
            b,d=locate()
            protocol=read(d/'protocol.json') if d else {}
            if protocol.get('status')=='failed':raise RuntimeError('Diagnostic failed: '+protocol.get('error','unknown'))
            n=len(read(b/'results.json')) if b else 0
            m=len(read(d/'results.json')) if d and (d/'results.json').is_file() else 0
            if (n,m)!=previous:print('Analysis waiting:',n,'/24 baseline,',m,'/16 diagnostic',flush=True);previous=(n,m)
            if n==24 and m==16 and protocol['status']=='complete' and (d/'restored-state.json').is_file():return b,d
        except (OSError,ValueError):pass
        time.sleep(10)

def csv_write(path,rows):
    with path.open('w',newline='',encoding='utf-8-sig') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def paired_summary(a,b,key):
    # Pair adjacent AB/BA trials. The unit of replication is a run pair, not a token or request.
    differences=[(y[key]-x[key]) if key=='requests_s' else (x[key]-y[key]) for x,y in zip(a,b)]
    gains=[d/x[key]*100 for x,d in zip(a,differences)]
    n=len(differences);critical={4:3.1824463053,6:2.5705818366}[n]
    mean=statistics.mean(differences);sd=statistics.stdev(differences)
    half=critical*sd/math.sqrt(n)
    mean_gain=statistics.mean(gains);gain_half=critical*statistics.stdev(gains)/math.sqrt(n)
    return {'pairs':n,'metric':key,'mean_favorable_difference':mean,'difference_ci95_low':mean-half,
            'difference_ci95_high':mean+half,'mean_paired_gain_pct':mean_gain,
            'gain_ci95_low_pct':mean_gain-gain_half,'gain_ci95_high_pct':mean_gain+gain_half,
            'all_pairs_favor_least_outstanding':all(v>0 for v in differences),
            'conclusion':'LO favored under tested conditions' if mean_gain-gain_half>0 else 'RR favored under tested conditions' if mean_gain+gain_half<0 else 'Paired uncertainty includes no difference'}

def validate_runs(baseline,diagnostic):
    base=read(baseline/'results.json');diag=read(diagnostic/'results.json')
    assert len(base)==24 and len(diag)==16
    rows=[];references={};outputs={};tokens_checked=0
    request_rows=[];worker_rows=[]
    for family,results in [('random',base),('order',diag)]:
        for r in results:
            folder=ROOT/'runs/llm'/r['run_id'];cfg=read(folder/'config.json');work=read(folder/'workload.json');requests=read(folder/'requests.json')
            c=check_run(folder)
            if not c['passed'] or not c['all_completed']:raise RuntimeError('Correctness failure '+r['run_id']+': '+str(c['errors']))
            expected_count=120 if family=='random' else 64
            assert len(work)==expected_count and r['successes']==expected_count
            assert cfg['backend']=='cpu-model' and cfg['settings']['execution']=='selective' and cfg['settings']['scheduling']=='continuous'
            assert cfg['settings']['slots']==4 and cfg['settings']['prefill_chunk']==128 and cfg['settings']['kv_budget']==4096
            assert cfg['environment']['workers']==2 and cfg['environment']['model_threads_per_worker']==2
            assert all(w['dtype']=='torch.float32' and w['model']=='Qwen/Qwen2.5-0.5B-Instruct' for w in cfg['worker_start'])
            phase='random' if family=='random' else r['workload_pattern']
            contract_key=(family,phase,float(r['rate']))
            shape=[(x['prompt'],x['max_tokens'],x['class'],x['arrival_s']) for x in work]
            if contract_key in references:assert references[contract_key]==shape,'Workload differs within a comparison'
            else:references[contract_key]=shape
            events=read_worker_events(folder)
            by_id=collections.defaultdict(list);input_counts={}
            for e in events:
                if e['event']=='token':by_id[e['request_id']].append(e)
                elif e['event']=='queued':input_counts[e['request_id']]=e['input_tokens']
            generated=[[e['token_id'] for e in sorted(by_id[x['request_id']],key=lambda e:e['seq'])] for x in work]
            output_key=(family,phase)
            if output_key in outputs:assert outputs[output_key]==generated,'Model outputs differ under routing or load changes'
            else:outputs[output_key]=generated
            tokens_checked+=sum(map(len,generated))
            assert abs(percentile([x['ttft_ms'] for x in requests],.95)-r['ttft_p95_ms'])<1e-6
            assert abs(percentile([x['latency_ms'] for x in requests],.95)-r['latency_p95_ms'])<1e-6
            cleanup=read(folder/'cleanup.json')
            assert all(not w.get('kv_payload_bytes',0) for w in cleanup['workers'])
            row={'family':family,'phase':phase,**r}
            for kind in ('short','long'):
                for source,target in [('queue_ms','queue_p95_ms'),('ttft_ms','ttft_p95_ms'),('latency_ms','latency_p95_ms')]:
                    row[f'{kind}_{target}']=percentile([x[source] for x in requests if x['class']==kind],.95)
            samples=[json.loads(x) for x in (folder/'samples.jsonl').read_text(encoding='utf-8').splitlines()]
            row['gateway_cpu_s']=(samples[-1]['gateway_cpu_s']-samples[0]['gateway_cpu_s']) if len(samples)>1 else None
            window=samples[-1]['t']-samples[0]['t']
            # Process CPU / wall time is a logical-core equivalent, not host utilization or kernel time.
            row['worker_process_cpu_core_equivalents']=(sum(w['cpu_process_s'] for w in samples[-1]['workers'])-sum(w['cpu_process_s'] for w in samples[0]['workers']))/window
            row['mean_worker_slot_saturation_fraction']=statistics.mean(v['active_slot_saturation_fraction'] for v in r['pressure'].values())
            for w in cfg['worker_start']:
                wid=w['id'];assigned=[x for x in requests if x['worker']==wid];finish=next(v for v in cleanup['workers'] if v['id']==wid)
                worker_rows.append({'family':family,'phase':phase,'rate':r['rate'],'repeat':r['repeat'],'policy':r['routing'],'worker':wid,
                                    'short_requests':sum(x['class']=='short' for x in assigned),'long_requests':sum(x['class']=='long' for x in assigned),
                                    'input_tokens':sum(input_counts[x['request_id']] for x in assigned),'output_tokens':sum(x['tokens'] for x in assigned),
                                    'cpu_process_s':finish['cpu_process_s']-w['cpu_process_s'],
                                    'max_queue':r['pressure'][wid]['max_queue'],
                                    'active_slot_saturation_fraction':r['pressure'][wid]['active_slot_saturation_fraction']})
            for x in requests:request_rows.append({'family':family,'phase':phase,'rate':r['rate'],'repeat':r['repeat'],'policy':r['routing'],
                                                  **{k:x[k] for k in ['request_id','class','worker','tokens','ttft_ms','latency_ms','queue_ms','dispatch_lateness_ms']}})
            rows.append(row)
    assert sum(r['count'] for r in rows)==3904
    csv_write(OUT/'all-requests.csv',request_rows);csv_write(OUT/'worker-distribution.csv',worker_rows)
    summaries=[];paired=[]
    for key in sorted({(r['family'],r['phase'],float(r['rate'])) for r in rows}):
        family,phase,rate=key
        groups={p:sorted([r for r in rows if (r['family'],r['phase'],float(r['rate']))==key and r['routing']==p],key=lambda r:r['repeat']) for p in POLICIES}
        assert len(groups['round_robin'])==len(groups['least_outstanding'])==(6 if family=='random' else 4)
        for p,obs in groups.items():
            summary={'family':family,'phase':phase,'rate':rate,'policy':p,'repeats':len(obs),'requests_per_trial':obs[0]['count']}
            for metric in METRICS+CLASS_METRICS+['dispatch_lateness_p95_ms','gateway_cpu_s','worker_process_cpu_core_equivalents','mean_worker_slot_saturation_fraction']:
                values=[x[metric] for x in obs];summary[metric+'_mean']=statistics.mean(values);summary[metric+'_sample_sd']=statistics.stdev(values)
            summaries.append(summary)
        for metric in METRICS[:3]:paired.append({'family':family,'phase':phase,'rate':rate,**paired_summary(groups['round_robin'],groups['least_outstanding'],metric)})
    csv_write(OUT/'summary.csv',summaries);csv_write(OUT/'paired-effects.csv',paired)
    (OUT/'summary.json').write_text(json.dumps(summaries,indent=2),encoding='utf-8')
    (OUT/'paired-effects.json').write_text(json.dumps(paired,indent=2),encoding='utf-8')
    validation={'all_40_runs_correct':True,'all_3904_requests_completed':True,'same_workload_within_each_comparison':True,
                'identical_greedy_token_ids_within_each_workload_family':True,'tokens_checked':tokens_checked,
                'resources_released':True,'scope':'Two real Qwen replicas on one CPU host. Fixed final backend. Order diagnostic is intentional, not representative traffic.'}
    (OUT/'validation.json').write_text(json.dumps(validation,indent=2),encoding='utf-8')
    return rows,summaries,paired,worker_rows,validation

def figures(rows,summaries,paired,workers):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'Segoe UI','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
    colors={'round_robin':'#3658B4','least_outstanding':'#C28443'}
    for family,name in [('random','Random_Mix_Comparison'),('order','Order_Diagnostic_Comparison')]:
        metrics=METRICS[:3];conditions=[('random',1.),('random',3.)] if family=='random' else [('long_first',3.),('short_first',3.)]
        fig,axes=plt.subplots(1,3,figsize=(14.7,4.6),layout='constrained')
        for ax,metric in zip(axes,metrics):
            scale=1 if metric=='requests_s' else 1000
            for pi,p in enumerate(POLICIES):
                for i,(phase,rate) in enumerate(conditions):
                    obs=[r[metric]/scale for r in rows if r['family']==family and r['phase']==phase and r['rate']==rate and r['routing']==p]
                    x=i+(-.12 if pi==0 else .12)
                    ax.errorbar(x,statistics.mean(obs),yerr=statistics.stdev(obs),fmt='o',color=colors[p],capsize=5,label=p.replace('_',' ').title() if i==0 else None,markersize=7)
                    ax.scatter([x+(j-(len(obs)-1)/2)*.016 for j in range(len(obs))],obs,color=colors[p],alpha=.5,s=18)
            for i,(phase,rate) in enumerate(conditions):
                selected={p:[r[metric]/scale for r in rows if r['family']==family and r['phase']==phase and r['rate']==rate and r['routing']==p] for p in POLICIES}
                rr=statistics.mean(selected['round_robin']);lo=statistics.mean(selected['least_outstanding'])
                gain=(lo/rr-1)*100 if metric=='requests_s' else (1-lo/rr)*100
                ax.annotate(f'LO improvement {gain:+.1f}%',(i,1),xycoords=('data','axes fraction'),xytext=(0,-5),textcoords='offset points',ha='center',va='top',fontsize=9,color='#66717D')
            ax.set_xticks(range(2),['1 request/s','3 requests/s'] if family=='random' else ['Long request first','Short request first'])
            upper=ax.get_ylim()[1]
            ax.set_title(LABELS[metric],fontsize=12,pad=15);ax.set_ylim(0,upper*1.18);ax.grid(axis='y',alpha=.18)
        axes[0].legend(frameon=False,fontsize=10)
        fig.suptitle('Random mixed requests: 120 per trial, 6 paired repeats' if family=='random' else 'Intentional order diagnostic: 64 per trial, 4 paired repeats per phase',fontsize=15)
        fig.savefig(OUT/(name+'.png'),dpi=180);fig.savefig(OUT/(name+'.svg'));plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11.5,4.5),layout='constrained')
    for ax,phase in zip(axes,['long_first','short_first']):
        for pi,p in enumerate(POLICIES):
            for wi,wid in enumerate(['worker-1','worker-2']):
                obs=[r for r in workers if r['family']=='order' and r['phase']==phase and r['policy']==p and r['worker']==wid]
                x=pi*3+wi
                short=statistics.mean(r['short_requests'] for r in obs);long=statistics.mean(r['long_requests'] for r in obs)
                ax.bar(x,short,color='#AABAD7',width=.7);ax.bar(x,long,bottom=short,color='#C28443',width=.7)
                ax.text(x,short+long+.7,f'{long:.1f} long',ha='center',fontsize=9)
        ax.set_xticks([0,1,3,4],['Worker 1','Worker 2','Worker 1','Worker 2'])
        ax.text(.5,-.16,'Round robin',transform=ax.get_xaxis_transform(),ha='center',fontweight='bold')
        ax.text(3.5,-.16,'Least outstanding',transform=ax.get_xaxis_transform(),ha='center',fontweight='bold')
        ax.set_ylim(0,48);ax.set_title(phase.replace('_',' ').title());ax.set_ylabel('Mean requests assigned per worker')
    from matplotlib.patches import Patch
    axes[0].legend(handles=[Patch(color='#AABAD7',label='Short'),Patch(color='#C28443',label='Long')],frameon=False)
    fig.suptitle('Why arrival order matters: measured assignment counts',fontsize=14)
    fig.savefig(OUT/'Diagnostic_Worker_Distribution.png',dpi=180);fig.savefig(OUT/'Diagnostic_Worker_Distribution.svg');plt.close(fig)

def report(summaries,paired,validation):
    esc=html.escape
    def condition(r):
        return f'随机混合 {r["rate"]:g}/s' if r['family']=='random' else ('顺序诊断：长先到' if r['phase']=='long_first' else '顺序诊断：短先到')
    def table(family):
        text='<table><tr><th>条件</th><th>策略</th><th>吞吐 req/s</th><th>P95 首 token / s</th><th>P95 完成 / s</th></tr>'
        for r in summaries:
            if r['family']!=family:continue
            label=(str(r['rate'])+' 请求/秒') if family=='random' else ('长请求先到' if r['phase']=='long_first' else '短请求先到')
            vals=[]
            for metric in METRICS[:3]:
                scale=1 if metric=='requests_s' else 1000
                vals.append(f'{r[metric+"_mean"]/scale:.3f} ± {r[metric+"_sample_sd"]/scale:.3f}')
            text+='<tr>'+''.join('<td>'+esc(str(v))+'</td>' for v in [label,r['policy'],*vals])+'</tr>'
        return text+'</table>'
    body='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TokenFlow / Expanded routing results</title><style>body{max-width:1150px;margin:40px auto;padding:0 25px;color:#1c2938;font:16px/1.8 "Segoe UI","Microsoft YaHei",sans-serif;background:#fff}h1{font-size:34px}h2{margin-top:40px}a{color:#3658b4}img{width:100%;margin:20px 0}table{width:100%;border-collapse:collapse;font-size:14px}td,th{text-align:left;border-bottom:1px solid #dce2eb;padding:10px}.note{color:#66717d;font-size:14px}.effect{padding:13px 0;border-bottom:1px solid #e2e6ee}code{font-family:Consolas,monospace}</style><body><a href="../Experiment_Progress.html">返回进度页</a><h1>扩大路由对比：完整实验结果</h1><p>所有预定的 40 轮、3,904 个真实 Qwen 请求完成并通过检查。两个完整 Qwen2.5-0.5B 副本共享一台 CPU 主机，FP32，每 worker 两个计算线程、四个槽位、4096-token KV 预留预算。执行方式固定为 selective batching、continuous admission 和每轮 128-token 共享 prefill 额度。</p><p>同一个比较内使用相同请求、输出上限、到达偏移和资源。每轮先预热再测量，并以 AB/BA 交替策略顺序。下表为各轮指标的均值 ± 样本标准差，不是把请求混起来得到的一个 P95。</p><h2>1．随机混合基线</h2><p>每轮 120 个请求，每个到达率下每种策略重复六次，共 2,880 个请求。固定间隔、开放式到达，seed 3010，短／长输出上限 16／48 tokens。1 请求/秒是较低的受测速率，不能预先认定它没有拥塞。</p>'''
    body+='<p>工作负载是用于机制比较的合成输入，只包含短／长两种 prompt 模板，长请求在固定 seed 下有 39 个、短请求 81 个。相同模板被重复提交，真实推理没有跨请求前缀缓存。它不是多样化真实用户问答样本，也不是回答质量评测。</p>'
    body+=table('random')+'<img src="Random_Mix_Comparison.png" alt="Random mixed request comparison">'
    body+='<h2>2．长短交替到达诊断</h2><p>每轮 64 个请求，长短各半，3 请求/秒。长先到、短先到两种顺序都测，各策略每种顺序重复四次，共 1,024 个请求。这是明确设计的顺序敏感性压力场景。两个顺序的请求内容多重集合相同，但与随机基线的长请求比例和数量不同，因此分别报告，不能把诊断收益当成一般生产流量收益。</p>'
    body+=table('order')+'<img src="Order_Diagnostic_Comparison.png" alt="Order diagnostic comparison"><img src="Diagnostic_Worker_Distribution.png" alt="Measured worker assignments">'
    body+='<p class="note">比较图上方的改善比例由两种策略的各轮均值计算；下方置信区间则先在每对试验内计算相对改善，再对配对百分比取均值。这两种计算顺序不同，数值可以略有不同。</p>'
    body+='<h2>不能忽略的取舍：短请求是否变慢？</h2><p>顺序诊断的总体指标偏向 least outstanding，但短请求等待反而变长。轮询在这个特殊顺序下，把长短请求分开到两个 worker；短请求意外获得了专用 worker。least outstanding 混合两类请求，减少长请求的尾部等待，同时损失了这种短请求隔离。它按请求数量选择，也没有完全平衡 token 工作量：长先到时，32 个长请求的分配从 RR 的 32/0 变为 LO 平均 26/6；短先到则从 0/32 变为平均 6.25/25.75。</p>'
    body+='<p>下表每个值均为各轮对应类别 P95 的均值 ± 样本标准差，单位秒。类别内部和总体 P95 的样本集合不同，不能互相替代。</p><table><tr><th>条件</th><th>策略</th><th>类别</th><th>排队 P95 / s</th><th>首 token P95 / s</th><th>完成 P95 / s</th></tr>'
    for r in summaries:
        for kind in ('short','long'):
            vals=[condition(r),r['policy'],'短请求' if kind=='short' else '长请求']
            for metric in ('queue_p95_ms','ttft_p95_ms','latency_p95_ms'):
                key=f'{kind}_{metric}'
                vals.append(f'{r[key+"_mean"]/1000:.2f} ± {r[key+"_sample_sd"]/1000:.2f}')
            body+='<tr>'+''.join('<td>'+esc(str(v))+'</td>' for v in vals)+'</tr>'
    body+='</table><h2>共享硬件能解释差异不明显吗？</h2><p><strong>可能是限制因素，但现有实验没有证明硬件是原因。</strong>两个进程共享同一台 CPU 主机和内存子系统，不代表有两套独立物理算力。路由可能减少一个 worker 空闲、另一个积压造成的损失，但不能凭空增加资源。如果两边都已有足够工作，改善排队也未必显著改变总吞吐。</p><p>随机负载下，轮询每轮已把 39 个长请求分为 18/21。3/s 下两种策略的槽位占满比例接近，因此可纠正的不均衡可能有限。least outstanding 只看未完成请求数，仍把长短请求各算作一个，不能准确表示剩余计算工作。以上是与日志相符的机制解释，尚未通过改变硬件或绑核的对照实验验证。</p>'
    body+='<table><tr><th>随机负载条件</th><th>策略</th><th>worker 槽位占满比例</th><th>两 worker 进程 CPU / 墙钟秒</th></tr>'
    for r in summaries:
        if r['family']!='random':continue
        vals=[condition(r),r['policy'],f'{100*r["mean_worker_slot_saturation_fraction_mean"]:.1f}%',f'{r["worker_process_cpu_core_equivalents_mean"]:.2f} 核当量']
        body+='<tr>'+''.join('<td>'+esc(str(v))+'</td>' for v in vals)+'</tr>'
    body+='</table><p class="note">槽位占满比例是各轮、各 worker 采样比例的平均，表示应用并发上限。CPU 核当量由采样窗口内两个 worker 的进程 CPU 时间增量除以墙钟时间得到，包含框架开销。每个 worker 配置两个 PyTorch 计算线程。这些值不能证明整机 CPU、内存带宽、功耗或温度已经饱和；本次没有记录这些硬件计数器。热状态、后台任务和跨机器表现仍是限制。</p><p>反证是：同一硬件在顺序诊断中仍出现总体收益，所以“机器差导致任何路由都一样”不符合全部结果。要进一步检验硬件影响，应固定工作负载、引擎和资源预算，对照共享 CPU 与隔离核心或独立主机，并在各自容量附近比较不同到达率。单纯换一张 GPU 会同时改变服务速度和负载强度，不能单独建立因果关系。</p>'
    body+='<p>公开依据：<a href="https://docs.pytorch.org/docs/stable/notes/multiprocessing.html">PyTorch 多进程资源竞争说明</a>、<a href="https://docs.vllm.ai/en/v0.11.2/getting_started/installation/cpu/">vLLM CPU 线程与核心配置</a>、<a href="https://www.usenix.org/system/files/osdi24-sun-biao.pdf">Llumnix，OSDI 2024</a>。这些来源支持相关机制，并没有验证本项目的具体硬件瓶颈。</p>'
    body+='<h2>3．差异与不确定性</h2><p>下面按相邻的同一重复轮次配对，正值表示 least outstanding 更好：吞吐量取 LO−RR，延迟取 RR−LO。95% 区间使用配对差的 Student t 近似。六对或四对试验仍然较少，且同机连续运行可能有时间相关性，所以这些区间不构成跨硬件、跨负载的保证。主要指标是吞吐量，延迟作为次要指标分别报告。</p>'
    for r in paired:
        condition=(f'随机混合 {r["rate"]:g}/s' if r['family']=='random' else '顺序诊断 '+('长先到' if r['phase']=='long_first' else '短先到'))
        body+=f'<div class="effect"><strong>{condition} / {esc(LABELS[r["metric"]])}</strong><br>配对平均改善 {r["mean_paired_gain_pct"]:.1f}%，95% 区间 [{r["gain_ci95_low_pct"]:.1f}%，{r["gain_ci95_high_pct"]:.1f}%]。{esc(r["conclusion"])}</div>'
    body+='''<h2>这些指标有什么用？</h2><p><strong>吞吐量</strong>看单位时间完成多少工作。<strong>首 token 延迟</strong>看用户等多久才能看到回答开始。<strong>P95 完成延迟</strong>关注较慢的那部分请求什么时候才能收完整个回答。到达率是输入压力，不是测出来的处理能力；固定到达的有限负载下，吞吐量还会受到到达间隔和最后一批排空时间影响。</p><p>不能单靠“最大队列不为零”判断硬件瓶颈。配套 CSV 提供短长请求的等待时间、负载生成器发送迟到量、worker 队列/槽位压力及进程 CPU 时间。进程 CPU 数据包含框架与服务开销，不能直接当作模型内核时间。</p><h2>证据与使用范围</h2><p>所有轮次检查请求身份、分配、token 顺序、唯一终态、输出长度和资源清理。每种工作负载内部，不同策略和重复轮次生成的 token ID 完全一致。历史的 16 请求路由实验与本次最终后端实验分开保留。本次记录也不替换 earlier selective batching 的 +46.7% 对照实验。</p><p>本报告只支持受测共享 CPU 主机、模型、调度设置和请求内容下的结论。到达顺序诊断是主动构造的机制实验，不代表常规流量。</p><p><a href="summary.csv">指标均值与波动 CSV</a> · <a href="paired-effects.csv">配对差异与区间 CSV</a> · <a href="all-requests.csv">逐请求数据</a> · <a href="worker-distribution.csv">worker 负载分布</a> · <a href="Raw_Evidence.zip">完整原始证据</a> · <a href="validation.json">验证记录</a></p></body></html>'''
    (OUT/'Results.html').write_text(body,encoding='utf-8')

def presentation_notes(summaries,paired):
    lines=['EXPANDED ROUTING COMPARISON / ENGLISH AND CHINESE','Use these new measurements separately from the historical 16-request result.','']
    en='I expanded the routing comparison to 120 mixed short and long requests per trial. Each policy ran six times at each of two arrival rates, with alternating order. The final real-Qwen backend, worker count and resource limits stayed fixed within each comparison.'
    zh='我把路由实验扩大到每轮 120 个长短混合请求。在两个到达率下，每种策略各重复六次，并交替顺序。同一比较中，最终真实 Qwen 后端、worker 数量和资源限制保持固定。'
    lines += [en,zh,'']
    for rate in (1.,3.):
        r=next(x for x in summaries if x['family']=='random' and x['rate']==rate and x['policy']=='round_robin')
        l=next(x for x in summaries if x['family']=='random' and x['rate']==rate and x['policy']=='least_outstanding')
        en=(f'At {rate:g} arrival'+('s' if rate!=1 else '')+f' per second, round robin averaged {r["requests_s_mean"]:.3f} completed requests per second, compared with {l["requests_s_mean"]:.3f} for least outstanding. '
            f'Mean trial P95 time to first token was {r["ttft_p95_ms_mean"]/1000:.2f} versus {l["ttft_p95_ms_mean"]/1000:.2f} seconds. '
            f'P95 completion latency was {r["latency_p95_ms_mean"]/1000:.2f} versus {l["latency_p95_ms_mean"]/1000:.2f} seconds.')
        zh=(f'每秒到达 {rate:g} 个请求时，轮询平均每秒完成 {r["requests_s_mean"]:.3f} 个请求，最少未完成请求策略为 {l["requests_s_mean"]:.3f} 个。'
            f'各轮 P95 首 token 延迟的均值分别为 {r["ttft_p95_ms_mean"]/1000:.2f} 秒和 {l["ttft_p95_ms_mean"]/1000:.2f} 秒，'
            f'P95 完成延迟分别为 {r["latency_p95_ms_mean"]/1000:.2f} 秒和 {l["latency_p95_ms_mean"]/1000:.2f} 秒。')
        lines += [en,zh,'']
        for metric in METRICS[:3]:
            effect=next(x for x in paired if x['family']=='random' and x['rate']==rate and x['metric']==metric)
            lines += [f'[Evidence] {metric}: mean paired improvement {effect["mean_paired_gain_pct"]:+.1f}%, 95% interval [{effect["gain_ci95_low_pct"]:+.1f}%, {effect["gain_ci95_high_pct"]:+.1f}%]. {effect["conclusion"]}.']
        lines.append('')
    lines += [
        'I also tested an intentional arrival-order diagnostic. Long and short requests alternate, and I test both starting phases. The two policies receive exactly the same workload within each comparison. This probes round robin’s sensitivity to request order, rather than estimating representative production gains.',
        '我还单独做了一个到达顺序诊断：长短请求交替到达，并交换谁先到。每一组内部，两种策略收到完全相同的请求。这是在检验轮询对请求顺序的敏感性，不能把这种有意构造的压力场景当成一般生产流量。','',
        'The diagnostic also exposes a tradeoff. With long requests arriving first, the mean trial P95 queue time for short requests rises from 3.20 seconds under round robin to 18.03 seconds under least outstanding. With the other starting phase, it rises from 7.60 to 25.33 seconds. Round robin accidentally segregates the two length classes; least outstanding improves the aggregate tail but loses that short-request isolation.',
        '这个诊断也暴露出取舍。长请求先到时，短请求各轮 P95 排队时间的均值，从轮询的 3.20 秒增加到最少未完成请求策略的 18.03 秒。交换起始顺序后，则从 7.60 秒增加到 25.33 秒。轮询意外把长短请求分开，最少未完成请求策略改善了总体尾部指标，却损失了这种短请求隔离。','',
        'Q: Could the hardware hide a routing advantage?',
        'A: Possibly. Both model processes share one CPU host, and changing routing does not add compute capacity. At three arrivals per second, the mean full-slot sampling fraction is about 93 percent for round robin and 90 percent for least outstanding. However, slots are an application limit, not proof that the whole CPU or memory bandwidth is saturated. The same host still shows gains in the intentional order diagnostic. Isolated cores or separate hosts would be needed to test the hardware explanation directly.',
        '问：会不会是设备限制，让路由优势不明显？',
        '答：有可能。两个模型进程共享一台 CPU 主机，改变路由不会增加总算力。每秒到达三个请求时，轮询的槽位占满采样比例平均约为 93%，最少未完成请求策略约为 90%。但槽位是应用层上限，不能证明整台 CPU 或内存带宽已经饱和。而且同一台机器在有意构造的到达顺序诊断中仍有收益。要直接检验硬件解释，还需要隔离核心或独立主机的对照实验。','',
        'All 3,904 requests completed and passed lifecycle checks. Greedy output token IDs matched across routing policies within each workload family. The figures show every planned trial, with mean and sample standard deviation.',
        '全部 3,904 个请求完成并通过生命周期检查。在每种工作负载内部，不同路由策略的贪心输出 token ID 一致。图表保留了所有预定轮次，并显示均值和样本标准差。','',
        'Q: Did increasing sample size alone create the advantage?',
        'A: The older experiment also used an earlier backend. Therefore, old-versus-new differences cannot be attributed only to sample size. The expanded experiment isolates routing within the final backend. More requests and repeats improve the evidence for that particular comparison.',
        '问：是不是只要样本变大，优势就出来了？',
        '答：旧实验同时使用了较早的后端，因此不能把旧结果和新结果的差别全部归因于样本数。这次是在最终后端内部控制其他条件，只比较路由；更多请求和重复轮次让这组比较的依据更充分。','',
        'Assignment boundary: the course requires the two routing policies, the same mixed workload and the specified metrics. It does not prescribe 16 or 120 requests, 3 arrivals/s, four slots, or three/six repeats. Those are experimental choices.',
        '作业边界：老师要求实现两种路由、使用同样的混合负载并测量指定指标，没有规定必须 16 或 120 个请求、每秒 3 个、四个槽位或重复三／六次。这些数字是实验设计选择。'
    ]
    (OUT/'Presentation_Update_EN_ZH.txt').write_text('\n'.join(lines),encoding='utf-8')

def archive(rows,baseline,diagnostic):
    with zipfile.ZipFile(OUT/'Raw_Evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for r in rows:
            folder=ROOT/'runs/llm'/r['run_id']
            for path in folder.iterdir():
                if path.is_file():z.write(path,'runs/'+folder.name+'/'+path.name)
        for family,folder in [('random-suite',baseline),('diagnostic-suite',diagnostic)]:
            for name in ['results.json','summary.csv','protocol.json','restored-state.json']:
                p=folder/name
                if p.is_file():z.write(p,family+'/'+name)
        z.write(LOG/'protocol.json','random-suite/requested-protocol.json')
        for name in ['run_routing_order_diagnostic.py','analyze_expanded_routing.py']:
            z.write(ROOT/'scripts'/name,'scripts/'+name)

def main(wait):
    OUT.mkdir(exist_ok=True)
    baseline,diagnostic=wait_for_completion() if wait else locate()
    if wait:
        # Load the final saved analysis code after measurements rather than retaining a waiting process's old module.
        subprocess.run([sys.executable,'-u',str(Path(__file__).resolve())],check=True)
        return
    if not baseline or not diagnostic:raise RuntimeError('Both complete suites are required')
    if read(diagnostic/'protocol.json')['status']!='complete' or not(diagnostic/'restored-state.json').is_file():raise RuntimeError('Diagnostic and demo restoration not complete')
    if importlib.util.find_spec('matplotlib') is None:
        # Set up plotting only after inference measurements. Keep the model environment unchanged.
        plot_env=ROOT/'.runtime/routing-analysis-venv'
        plot_python=plot_env/'Scripts/python.exe'
        if not plot_python.is_file():subprocess.run([sys.executable,'-m','venv',str(plot_env)],check=True)
        subprocess.run([str(plot_python),'-m','pip','install','-r',str(ROOT/'requirements-plots.txt')],check=True)
        subprocess.run([str(plot_python),'-u',str(Path(__file__).resolve())],check=True)
        return
    print('Validating all runs and exact outputs...',flush=True)
    rows,summaries,paired,workers,validation=validate_runs(baseline,diagnostic)
    figures(rows,summaries,paired,workers);report(summaries,paired,validation);presentation_notes(summaries,paired);archive(rows,baseline,diagnostic)
    metadata={'complete':True,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_suite':str(baseline),
              'diagnostic_suite':str(diagnostic),'requests':3904,'trials':40,
              'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.is_file() and p.name not in {'analysis-complete.json','analysis-error.json'}}}
    (OUT/'analysis-complete.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    print('ANALYSIS_COMPLETE',OUT,flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--wait',action='store_true');args=parser.parse_args()
    try:main(args.wait)
    except Exception as error:
        OUT.mkdir(exist_ok=True);(OUT/'analysis-error.json').write_text(json.dumps({'error':str(error)}),encoding='utf-8');raise
